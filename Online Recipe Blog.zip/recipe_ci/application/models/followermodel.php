<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Followermodel extends CI_Model {


    public function insert($followed_by,$id)
    {
        $sql = "INSERT INTO followers VALUES (null, '$id','$followed_by')";
        $this->load->database();
        $this->db->query($sql);

    }

    

}