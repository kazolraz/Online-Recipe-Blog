<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Likemodel extends CI_Model {


    public function insert($user_id,$id,$now)
    {
        $sql = "INSERT INTO likes VALUES (null, '$user_id','$id','$now')";
        $this->load->database();
        $this->db->query($sql);

    }

    public function total_likes()
    {
        $sql = "SELECT COUNT(id) as num_of_likes FROM likes";
        $this->load->database();
        $result = $this->db->query($sql);
        return $result->result_array();
    }

}