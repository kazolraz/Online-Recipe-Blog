<!DOCTYPE html>
<html lang="en">
<head>
<script>
         function valide()
		 {
			 var name=document.forms["add"]["name"].value;
			 if(name==null || name=="")
			 {
				 alert("name is empty");
				 return false;
			 }
			 
			 var description=document.forms["add"]["description"].value;
			 if(description==null || description=="")
			 {
				 alert("Description is empty");
				 return false;
			 }
			 
			 var preparation_time=document.forms["add"]["preparation_time"].value;
			 if(preparation_time==null || preparation_time=="")
			 {
				 alert("Preparation time is empty");
				 return false;
			 }
			 var cooking_time=document.forms["add"]["cooking_time"].value;
			 if(cooking_time==null || cooking_time=="")
			 {
				 alert("Cooking time is empty");
				 return false;
			 }
			 var ingredients=document.forms["add"]["ingredients"].value;
			 if(ingredients==null || ingredients=="")
			 {
				 alert("Ingredients is empty");
				 return false;
			 }
			 var procedures=document.forms["add"]["procedures"].value;
			 if(procedures==null || procedures=="")
			 {
				 alert("Procedures is empty");
				 return false;
			 }
		 }		 
	
	</script>

<style type="text/css">
	label{
		color: red;
	}
</style>
</head>
<body>
	<h1 align="center">Add Recipe</h1>
	
	<hr>
	<br/>
	<h3 align="center"><a href="/recipe_ci/admin">Back To Home</a><br/></h3>
	<h3 align="center"><a href="/recipe_ci/login/logout">Log Out</a><br/></h3>
	<hr>
	<br>
	
	
	<br/>
	<form name="add" method="post" align="center" onsubmit="return valide()">
		Name: <input type="text" name="name" value="<?php echo set_value('name'); ?>" size="40"/>
		<br/>
		<br/>
		Category: <select name="cat">
					<?php foreach ($cats as $cat){ ?>
						<option value="<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></option>
					<?php } ?>
					</select>
		<br/>
		<br/>
		Type: <input type="radio" name="type" value="regular" checked> regular
              <input type="radio" name="type" value="special"> special
		<br/>
		<br/>
		Description:<br/>
		<textarea name="description" rows="4" cols="50"></textarea>
		<br/>
		<br/>
		Difficulty:  <select name="difficulty" >
						   <<?php foreach ($diff as $difficulty){ ?>
                <option value="<?php echo $difficulty['id']; ?>"><?php echo $difficulty['type']; ?></option>
            <?php } ?>

					 </select>
		<br/>
		<br/>
		Preparation time: <input type="text" name="preparation_time" value="<?php echo set_value('preparation_time'); ?>"/>
		<br/>
		<br/>
        Cooking time: <input type="text" name="cooking_time" value="<?php echo set_value('cooking_time'); ?>" /></div>
		<br/>
		<br/>
		Serves: <input type="text" name="serves" value="<?php echo set_value('serves'); ?>" /></div>
		<br/>
		<br/>
		Ingredients:<br/>
		<textarea name="ingredients" value="<?php echo set_value('ingredients'); ?>" rows="4" cols="50"></textarea>
		<br/>
		<br/>
		Procedure:<br/>
		<textarea name="procedures" value="<?php echo set_value('procedures'); ?>" rows="4" cols="50"></textarea>
		<br/>
		<br/>
		
		
		<input type="submit" name="buttonSubmit" value="Save" />
	</form>
	<br/>
	<label align="center"><?php echo $message; ?></label>
	
</body>
</html>