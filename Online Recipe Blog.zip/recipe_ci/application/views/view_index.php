<!DOCTYPE html>
<html lang="en">
<head>
<script>
         function valide()
		 {
			 var email=document.forms["login"]["email"].value;
			 if(email==null || email=="")
			 {
				 alert("Email is Invalid");
				 return false;
			 }
			 
			 var pass=document.forms["login"]["password"].value;
			 if(pass==null || pass=="")
			 {
				 alert("password Invalid");
				 return false;
			 }
		 }		 
	
	</script>
	
</head>
<body>

	
	<form name="login" method="post" align="center" onsubmit="return valide()">
	<h1>Best cheff</h1>
	<hr>
	
	<br/>
	<h1>Login Here</h1>
	<hr>
	<br/>
		Email: <input type="text" name="email" value="<?php echo $email; ?>"/><br/></br>
		
	    Password:<input type="password" name="password"/><br/><br/>
		<span style="color:red"><?php echo $message; ?></span><hr/>
	<input type="submit"name="buttonSubmit"value="Login"/>
	<br/>
	<p>Not a member? Click <a href="/recipe_ci/login/sign_up">here</a> to Join our community.</p>
	
	</form>
</body>
</html>