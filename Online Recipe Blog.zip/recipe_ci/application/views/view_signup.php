<html>
	<head>
	<script>
         function valide()
		 {
			 var firstname=document.forms["sign_up"]["firstname"].value;
			 if(firstname==null || firstname=="")
			 {
				 alert("firstname is empty");
				 return false;
			 }
			 
			 var lastname=document.forms["sign_up"]["lastname"].value;
			 if(lastname==null || lastname=="")
			 {
				 alert("Lastname is empty");
				 return false;
			 }
			 
			 var email=document.forms["sign_up"]["email"].value;
			 if(email==null || email=="")
			 {
				 alert("Email is Invalid or empty");
				 return false;
			 }
			 var password=document.forms["sign_up"]["password"].value;
			 if(password==null || password=="")
			 {
				 alert("Password is Invalid or empty");
				 return false;
			 }
		 }		 
	
	</script>
		<title>Signup</title>
	<style type="text/css">
	label{
		color: red;
	}
    </style>
	
	</head>
	<body>
	<h1 align="center">Sign Up</h1>
	<br/>
	<br/>
	<hr>
	<br/>
	<br/>
	<form name="sign_up" method="post" align="center" onsubmit="return valide()">
		
			Firstname:<input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>"><br/><br/>
			Lastname:<input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>"><br/><br/>
			Email:<input type="email" name="email" value="<?php echo set_value('email'); ?>"><br/><br/>
			Password:<input type="password" name="password"><br/><br/>
			User type:<input type="text" name="u_type" value="user" readonly ><br/><br/>
			<input type="submit" name="buttonSubmit" value="Submit">
	</form>
			<label><?php echo $message; ?></label>
		
	</body>
</html>